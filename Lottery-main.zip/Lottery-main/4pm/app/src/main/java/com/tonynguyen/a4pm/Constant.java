package com.tonynguyen.a4pm;

public class Constant {
    public static final String domain = "https://xosohomnay.com.vn/";

}
